from flask import Flask
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from .models import User, db
from flask_mail import Mail
from flask_bcrypt import Bcrypt
from dotenv import load_dotenv
from flask_login import LoginManager
from flask_heroku import Heroku
import os

load_dotenv('.env')  # load environment variables from .env file

app = Flask(__name__)

# Load config from config.py
app.config.from_pyfile('config.py')

# Override or set SECRET_KEY from env or fallback to a secure random key for dev
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or os.urandom(24)

# Initialize Heroku integration
heroku = Heroku(app)

# Initialize database and migration
db.init_app(app)
migrate = Migrate(app, db)

# Initialize extensions
mail = Mail(app)
bcrypt = Bcrypt(app)

login = LoginManager(app)
login.login_view = 'login'

@login.user_loader
def load_user(user_id):
    return User.query.get(user_id)

from app import views
